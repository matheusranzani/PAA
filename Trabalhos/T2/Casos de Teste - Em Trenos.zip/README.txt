Arquivo zip gerado em: 12/02/2023 04:06:24 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Em Trenós